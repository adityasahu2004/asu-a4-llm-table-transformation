import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Define column groups
    hvac_cols = [
        'air1_sum', 'air2_sum', 'air3_sum', 'airwindowunit1_sum',
        'furnace1_sum', 'furnace2_sum', 'heater1_sum', 'heater2_sum', 'heater3_sum',
        'housefan1_sum', 'jacuzzi1_sum', 'pool1_sum', 'pool2_sum', 'poolpump1_sum', 'venthood1_sum'
    ]
    
    dwh_cols = [
        'waterheater1_sum', 'waterheater2_sum'
    ]
    
    major_appliance_cols = [
        'clotheswasher1_sum', 'clotheswasher_dryg1_sum', 'dishwasher1_sum',
        'drye1_sum', 'dryg1_sum', 'freezer1_sum', 'microwave1_sum',
        'oven1_sum', 'oven2_sum', 'range1_sum', 'refrigerator1_sum',
        'refrigerator2_sum', 'winecooler1_sum'
    ]
    
    lighting_cols = [
        'lights_plugs1_sum', 'lights_plugs2_sum', 'lights_plugs3_sum',
        'lights_plugs4_sum', 'lights_plugs5_sum', 'lights_plugs6_sum',
        'poollight1_sum', 'outsidelights_plugs1_sum', 'outsidelights_plugs2_sum',
        'security1_sum'
    ]
    
    misc_cols = [
        'aquarium1_sum', 'bathroom1_sum', 'bathroom2_sum',
        'bedroom1_sum', 'bedroom2_sum', 'bedroom3_sum', 'bedroom4_sum', 'bedroom5_sum',
        'battery1_sum', 'car1_sum', 'car2_sum', 'circpump1_sum',
        'diningroom1_sum', 'diningroom2_sum', 'disposal1_sum',
        'garage1_sum', 'garage2_sum', 'kitchen1_sum', 'kitchen2_sum',
        'kitchenapp1_sum', 'kitchenapp2_sum', 'livingroom1_sum', 'livingroom2_sum',
        'office1_sum', 'pump1_sum', 'shed1_sum', 'sprinkler1_sum',
        'utilityroom1_sum', 'wellpump1_sum', 'sumppump1_sum', 'sewerpump1_sum'
    ]

    # Helper to sum columns, treating NaN as 0
    def sum_cols(df, cols):
        # Filter out columns that might not exist in source (robustness)
        existing_cols = [c for c in cols if c in df.columns]
        if not existing_cols:
            return pd.Series(0.0, index=df.index)
        # Fill NaN with 0 to ensure sum is 0 if all are NaN or mixed
        return df[existing_cols].fillna(0).sum(axis=1)

    # Parse datetime
    # Source format: "M/D/YYYY H:MM" or similar. pd.to_datetime handles this flexibly.
    dt_series = pd.to_datetime(source['local_15min'])
    datetime_str = dt_series.dt.strftime('%Y-%m-%d %H:%M:%S')

    # Calculate aggregates
    hvac = sum_cols(source, hvac_cols)
    dwh = sum_cols(source, dwh_cols)
    major = sum_cols(source, major_appliance_cols)
    lighting = sum_cols(source, lighting_cols)
    misc = sum_cols(source, misc_cols)

    # Construct result
    result = pd.DataFrame({
        'datetime': datetime_str,
        'hvac': hvac.values,
        'domestic_water_heating': dwh.values,
        'major_appliances': major.values,
        'lighting': lighting.values,
        'miscellaneous_plug_loads': misc.values,
        'total': 0
    })

    # Ensure dtypes match target if necessary, though pandas usually infers float/int correctly
    # Target 'total' is int64
    result['total'] = result['total'].astype('int64')

    return result
