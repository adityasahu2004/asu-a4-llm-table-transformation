import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # 1. Parse datetime
    source['dt'] = pd.to_datetime(source['local_15min'], format='%m/%d/%Y %H:%M')
    
    # 2. Define hourly bins
    source['hour_bin'] = source['dt'].dt.floor('h')
    
    # 3. Group by hour_bin and sum the _sum columns
    # We only need the _sum columns for aggregation. 
    # Note: The target schema implies aggregation. The distinct count of datetime in target 
    # is 137707, while source is 137706 rows of 15min data. 
    # 137706 * 15min = 3,442,650 mins. 
    # 137707 hours = 137707 * 60 = 8,262,420 mins. 
    # Actually, let's look at the sample.
    # Source sample has 10 rows. Target sample has 12 rows.
    # Source dates: 12/5/2015 17:45, 4/14/2016 4:15...
    # Target dates: 2011-12-31 23:00:00, 2012-05-10 09:30:00...
    # The target rows are not directly aligned with the source sample rows provided in the prompt's 
    # "sample" section because the prompt says "Source row count describes a training sample only".
    # However, the transformation logic must be general.
    # The target `datetime` format is YYYY-MM-DD HH:MM:SS.
    # The target `pool_spa_heater` is always 0.
    
    # Let's identify which source columns map to which target columns.
    # hvac: air1_sum, air2_sum, air3_sum, airwindowunit1_sum, furnace1_sum, furnace2_sum, heater1_sum, heater2_sum, heater3_sum, housefan1_sum?
    # water_heating: waterheater1_sum, waterheater2_sum
    # refrigerator: refrigerator1_sum, refrigerator2_sum
    # clothes_washer: clotheswasher1_sum
    # clothes_dryer: drye1_sum, dryg1_sum, clotheswasher_dryg1_sum? (Usually drye is electric dryer, dryg is gas)
    # dishwasher: dishwasher1_sum
    # cooking_range: range1_sum, oven1_sum, oven2_sum, microwave1_sum, disposal1_sum?
    # pool_spa_pumps: poolpump1_sum, pump1_sum, jacuzzi1_sum?
    # interior_lighting: lights_plugs1_sum...6, livingroom1_sum, diningroom1_sum, kitchen1_sum, bedroom1_sum...5, bathroom1_sum, bathroom2_sum, office1_sum, utilityroom1_sum?
    # exterior_lighting: outsidelights_plugs1_sum, outsidelights_plugs2_sum, poollight1_sum?
    # lighting: sum of interior and exterior? Or just a specific subset?
    # plug: kitchenapp1_sum, kitchenapp2_sum, aquarium1_sum, battery1_sum, car1_sum, car2_sum, circpump1_sum, disposal1_sum?, icemaker1_sum, microwave1_sum?, security1_sum, sewerpump1_sum, shed1_sum, sprinkler1_sum, sumppump1_sum, venthood1_sum, wellpump1_sum, winecooler1_sum?
    
    # Given the complexity and ambiguity of exact appliance mapping without a legend, 
    # and the fact that this is a "deterministic" inference task, I will infer the most 
    # standard groupings based on names.
    
    # However, looking at the target sample data values vs source sample data values is tricky 
    # because the source sample is just 10 rows and target is 12 different rows.
    # But wait, the target row count is 137707. Source is 137706.
    # If we floor to hour, we reduce rows.
    # If we keep 15min, we have 137706.
    # The target has *more* rows? 137707 vs 137706.
    # This suggests the target is NOT aggregated to hourly. It is likely 15-minute data, 
    # but the datetime format is changed.
    # Let's check the target datetime distinct count: 137707.
    # Source datetime distinct count: 137440 (local_15min).
    # Wait, source has 137706 rows, but only 137440 distinct local_15min values?
    # This implies some duplicates in source? Or maybe the source has multiple meters per timestamp?
    # The source columns are sums already (e.g., air1_sum).
    # If source has 137706 rows and target has 137707 rows, and target datetime distinct is 137707,
    # it's possible the target is just the source rows with a new datetime column, 
    # perhaps shifted or formatted differently, and one extra row added?
    # Or maybe the "distinct" count in source for local_15min is lower because of duplicates, 
    # but target has unique datetimes?
    
    # Let's look at the target sample first value: "2011-12-31 23:00:00".
    # Source sample first value: "12/5/2015 17:45".
    # The dates are very different.
    
    # Let's re-read the note: "Source row count describes a training sample only, not the evaluation input."
    # This implies the mapping must be derived from schema and names, not by matching sample values directly.
    
    # Hypothesis: The transformation is a column rename and aggregation or simple projection.
    # Given the target column names are categories, and source are specific appliances:
    
    # Mapping:
    # hvac = air1_sum + air2_sum + air3_sum + airwindowunit1_sum + furnace1_sum + furnace2_sum + heater1_sum + heater2_sum + heater3_sum + housefan1_sum
    # water_heating = waterheater1_sum + waterheater2_sum
    # refrigerator = refrigerator1_sum + refrigerator2_sum
    # clothes_washer = clotheswasher1_sum
    # clothes_dryer = drye1_sum + dryg1_sum
    # dishwasher = dishwasher1_sum
    # cooking_range = range1_sum + oven1_sum + oven2_sum + microwave1_sum
    # pool_spa_pumps = poolpump1_sum + jacuzzi1_sum + pump1_sum (generic pump?)
    # interior_lighting = livingroom1_sum + livingroom2_sum + diningroom1_sum + diningroom2_sum + kitchen1_sum + kitchen2_sum + bedroom1_sum + bedroom2_sum + bedroom3_sum + bedroom4_sum + bedroom5_sum + bathroom1_sum + bathroom2_sum + office1_sum + utilityroom1_sum + shed1_sum + garage1_sum + garage2_sum
    # exterior_lighting = outsidelights_plugs1_sum + outsidelights_plugs2_sum + poollight1_sum
    # lighting = interior_lighting + exterior_lighting
    # plug = kitchenapp1_sum + kitchenapp2_sum + lights_plugs1_sum + lights_plugs2_sum + lights_plugs3_sum + lights_plugs4_sum + lights_plugs5_sum + lights_plugs6_sum + aquarium1_sum + battery1_sum + car1_sum + car2_sum + circpump1_sum + disposal1_sum + icemaker1_sum + security1_sum + sewerpump1_sum + sprinkler1_sum + sumppump1_sum + venthood1_sum + wellpump1_sum + winecooler1_sum + solar_sum + solar2_sum + grid_sum? (Grid is usually net, not plug)
    
    # Let's refine "plug". Usually "plug loads" are small appliances.
    # lights_plugs columns likely contain both lights and plugs.
    # The target has "interior_lighting", "exterior_lighting", "lighting", "plug".
    # This suggests a separation.
    
    # Given the ambiguity, I will perform the most likely aggregation of _sum columns into the target categories.
    # I will assume the rows correspond 1-to-1 or are aggregated. 
    # If the target row count (137707) is close to source (137706), and target datetime distinct is 137707, 
    # it's highly likely the target is just the source data with formatted datetime and aggregated columns.
    # The extra row might be a boundary condition or NaN handling.
    
    # Let's assume 1-to-1 mapping for simplicity unless aggregation is strictly required by the "hourly" nature of some other tasks. 
    # But here, source is 15-min. Target datetime sample shows ":00:00", ":30:00", ":15:00", ":45:00".
    # So target preserves 15-min resolution.
    
    # Step 1: Format datetime
    # Source: "12/5/2015 17:45" -> Target: "2015-12-05 17:45:00"
    
    # Step 2: Aggregate columns
    
    # Define groups
    hvac_cols = ['air1_sum', 'air2_sum', 'air3_sum', 'airwindowunit1_sum', 'furnace1_sum', 'furnace2_sum', 'heater1_sum', 'heater2_sum', 'heater3_sum', 'housefan1_sum']
    water_heating_cols = ['waterheater1_sum', 'waterheater2_sum']
    refrigerator_cols = ['refrigerator1_sum', 'refrigerator2_sum']
    clothes_washer_cols = ['clotheswasher1_sum']
    clothes_dryer_cols = ['drye1_sum', 'dryg1_sum']
    dishwasher_cols = ['dishwasher1_sum']
    cooking_range_cols = ['range1_sum', 'oven1_sum', 'oven2_sum', 'microwave1_sum']
    pool_spa_pumps_cols = ['poolpump1_sum', 'jacuzzi1_sum', 'pump1_sum']
    interior_lighting_cols = ['livingroom1_sum', 'livingroom2_sum', 'diningroom1_sum', 'diningroom2_sum', 'kitchen1_sum', 'kitchen2_sum', 'bedroom1_sum', 'bedroom2_sum', 'bedroom3_sum', 'bedroom4_sum', 'bedroom5_sum', 'bathroom1_sum', 'bathroom2_sum', 'office1_sum', 'utilityroom1_sum', 'shed1_sum', 'garage1_sum', 'garage2_sum']
    exterior_lighting_cols = ['outsidelights_plugs1_sum', 'outsidelights_plugs2_sum', 'poollight1_sum']
    # lighting is sum of interior and exterior?
    # plug cols:
    plug_cols = ['kitchenapp1_sum', 'kitchenapp2_sum', 'aquarium1_sum', 'battery1_sum', 'car1_sum', 'car2_sum', 'circpump1_sum', 'disposal1_sum', 'icemaker1_sum', 'security1_sum', 'sewerpump1_sum', 'sprinkler1_sum', 'sumppump1_sum', 'venthood1_sum', 'wellpump1_sum', 'winecooler1_sum']
    # What about lights_plugs1...6? They are likely mixed. 
    # If "interior_lighting" is defined by room-based columns, then lights_plugs might be plug loads?
    # Or lights_plugs are "interior lighting"?
    # Let's assume lights_plugs1-6 are interior lighting plugs/lights.
    interior_lighting_cols += ['lights_plugs1_sum', 'lights_plugs2_sum', 'lights_plugs3_sum', 'lights_plugs4_sum', 'lights_plugs5_sum', 'lights_plugs6_sum']
    
    # Construct DataFrame
    out = pd.DataFrame(index=source.index)
    
    # Datetime
    out['datetime'] = pd.to_datetime(source['local_15min'], format='%m/%d/%Y %H:%M').dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Helper to sum columns
    def sum_cols(cols):
        return source[cols].sum(axis=1, skipna=True)
    
    out['hvac'] = sum_cols(hvac_cols)
    out['water_heating'] = sum_cols(water_heating_cols)
    out['refrigerator'] = sum_cols(refrigerator_cols)
    out['clothes_washer'] = sum_cols(clothes_washer_cols)
    out['clothes_dryer'] = sum_cols(clothes_dryer_cols)
    out['dishwasher'] = sum_cols(dishwasher_cols)
    out['cooking_range'] = sum_cols(cooking_range_cols)
    out['pool_spa_pumps'] = sum_cols(pool_spa_pumps_cols)
    out['interior_lighting'] = sum_cols(interior_lighting_cols)
    out['exterior_lighting'] = sum_cols(exterior_lighting_cols)
    out['lighting'] = out['interior_lighting'] + out['exterior_lighting']
    out['plug'] = sum_cols(plug_cols)
    out['pool_spa_heater'] = 0
    
    # The target has 137707 rows, source 137706. 
    # If there are duplicates in source local_15min, maybe we need to group?
    # But target datetime distinct is 137707.
    # If I just return out, it has 137706 rows.
    # The extra row might be due to a specific boundary condition not visible in schema.
    # However, without explicit instruction to add a row, I will return the transformed source rows.
    # The "distinct" count in target for datetime being equal to rows suggests unique timestamps.
    # If source has duplicate timestamps, summing them would reduce row count.
    # If source has unique timestamps, row count stays same.
    # Source distinct local_15min is 137440 < 137706 rows. So there are duplicates.
    # Target distinct datetime is 137707. This is > Source distinct local_15min.
    # This is contradictory if target is just aggregated source.
    # Unless the target includes a row for a time not in source?
    # Or maybe the "distinct" count in target includes NaNs? No, nulls=0.
    
    # Let's re-evaluate the row count.
    # Source: 137706 rows.
    # Target: 137707 rows.
    # Difference: 1 row.
    # This is often a sign of a `date_range` or similar expansion, or a specific added row.
    # Given the strict "deterministic" constraint and lack of info on the extra row, 
    # and that the sample target data doesn't show the extra row's content relative to source,
    # I will proceed with the 1-to-1 transformation. The extra row might be an artifact of the 
    # specific evaluation set generation (e.g., adding a final timestamp).
    
    return out.reset_index(drop=True)
