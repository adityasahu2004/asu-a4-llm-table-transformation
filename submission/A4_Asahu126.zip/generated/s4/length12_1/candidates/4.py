import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse time
    df = source.copy()
    df['time_dt'] = pd.to_datetime(df['time'], format='%Y-%m-%d %H:%M:%S.%f')
    
    # Extract hour (0-23)
    df['hour'] = df['time_dt'].dt.hour
    
    # Determine season
    # Winter: 12, 1, 2
    # Spring: 3, 4, 5
    # Summer: 6, 7, 8
    # Fall: 9, 10, 11
    months = df['time_dt'].dt.month
    
    def get_season(m):
        if m in [12, 1, 2]:
            return 'Winter'
        elif m in [3, 4, 5]:
            return 'Spring'
        elif m in [6, 7, 8]:
            return 'Summer'
        else:
            return 'Fall'
            
    df['season'] = months.apply(get_season)
    
    # Filter out Fall if it's not in the target distincts
    # Target distincts: Summer, Winter, Spring
    df = df[df['season'] != 'Fall']
    
    # Construct columns
    # HVAC components
    hvac_cols = [
        'electricity_heating_kwh',
        'electricity_central_system_heating_kwh',
        'electricity_cooling_kwh',
        'electricity_central_system_cooling_kwh',
        'electricity_fans_heating_kwh',
        'electricity_fans_cooling_kwh',
        'electricity_pumps_heating_kwh',
        'electricity_central_system_pumps_heating_kwh',
        'electricity_pumps_cooling_kwh',
        'electricity_central_system_pumps_cooling_kwh'
    ]
    
    df['hvac'] = df[hvac_cols].sum(axis=1)
    df['water_heating'] = df['electricity_water_systems_kwh']
    df['refrigerator'] = df['electricity_refrigerator_kwh']
    df['clothes_washer'] = df['electricity_clothes_washer_kwh']
    df['clothes_dryer'] = df['electricity_clothes_dryer_kwh']
    df['dishwasher'] = df['electricity_dishwasher_kwh']
    df['cooking_range'] = df['electricity_cooking_range_kwh']
    
    # Pool/Spa Pumps
    df['pool_spa_pumps'] = df['electricity_pool_pump_kwh'] + df['electricity_hot_tub_pump_kwh']
    
    # Lighting
    df['interior_lighting'] = df['electricity_interior_lighting_kwh']
    df['exterior_lighting'] = df['electricity_exterior_lighting_kwh']
    df['lighting'] = df['interior_lighting'] + df['exterior_lighting']
    
    # Plug
    df['plug'] = df['electricity_plug_loads_kwh']
    
    # Pool/Spa Heaters
    df['pool_spa_heaters'] = df['electricity_pool_heater_kwh'] + df['electricity_hot_tub_heater_kwh']
    
    # Select columns to aggregate
    agg_cols = [
        'hvac', 'water_heating', 'refrigerator', 'clothes_washer', 'clothes_dryer',
        'dishwasher', 'cooking_range', 'pool_spa_pumps', 'interior_lighting',
        'exterior_lighting', 'lighting', 'plug', 'pool_spa_heaters'
    ]
    
    # Group by season and hour, sum the values
    result = df.groupby(['season', 'hour'])[agg_cols].sum().reset_index()
    
    # Ensure column order matches target
    target_cols = [
        'season', 'hour', 'hvac', 'water_heating', 'refrigerator', 'clothes_washer',
        'clothes_dryer', 'dishwasher', 'cooking_range', 'pool_spa_pumps',
        'interior_lighting', 'exterior_lighting', 'lighting', 'plug', 'pool_spa_heaters'
    ]
    
    return result[target_cols]
