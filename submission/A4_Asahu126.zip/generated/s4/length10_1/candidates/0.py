import pandas as pd
def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse time and format
    dt_series = pd.to_datetime(source['time'], format='%Y-%m-%d %H:%M:%S.%f')
    datetime_str = dt_series.dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Calculate HVAC sum
    hvac_cols = [
        'electricity_heating_kwh',
        'electricity_cooling_kwh',
        'electricity_fans_heating_kwh',
        'electricity_fans_cooling_kwh',
        'electricity_pumps_heating_kwh',
        'electricity_pumps_cooling_kwh',
        'electricity_central_system_pumps_heating_kwh',
        'electricity_central_system_pumps_cooling_kwh'
    ]
    hvac = source[hvac_cols].sum(axis=1)
    
    # Calculate Pool/Spa Pumps
    pool_spa_pumps = source['electricity_pool_pump_kwh'] + source['electricity_hot_tub_pump_kwh']
    
    # Calculate Lighting
    interior = source['electricity_interior_lighting_kwh']
    exterior = source['electricity_exterior_lighting_kwh']
    lighting = interior + exterior
    
    # Calculate Pool/Spa Heater
    pool_spa_heater = source['electricity_pool_heater_kwh'] + source['electricity_hot_tub_heater_kwh']
    
    # Construct result DataFrame
    out = pd.DataFrame({
        'datetime': datetime_str,
        'hvac': hvac,
        'water_heating': source['electricity_water_systems_kwh'],
        'refrigerator': source['electricity_refrigerator_kwh'],
        'clothes_washer': source['electricity_clothes_washer_kwh'],
        'clothes_dryer': source['electricity_clothes_dryer_kwh'],
        'dishwasher': source['electricity_dishwasher_kwh'],
        'cooking_range': source['electricity_cooking_range_kwh'],
        'pool_spa_pumps': pool_spa_pumps,
        'interior_lighting': interior,
        'exterior_lighting': exterior,
        'lighting': lighting,
        'plug': source['electricity_plug_loads_kwh'],
        'pool_spa_heater': pool_spa_heater
    })
    
    return out.reset_index(drop=True)
