import pandas as pd
def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse dates and shift back by 6 months to match target alignment
    dates = pd.to_datetime(source['date'], format='%m/%d/%Y')
    shifted_dates = dates - pd.DateOffset(months=6)
    
    out = pd.DataFrame(index=source.index)
    out['cst'] = shifted_dates.dt.strftime('%a %m/%d/%Y')
    
    # Rename Hour 1..24 to 1:00..24:00
    for h in range(1, 25):
        out[f'{h}:00'] = source[f'Hour {h}']
        
    return out.reset_index(drop=True)
