import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse date
    source = source.copy()
    source['dt'] = pd.to_datetime(source['date'], format='%m/%d/%Y')
    source['month'] = source['dt'].dt.month
    
    # Melt the value columns
    value_cols = [f'value{i}' for i in range(1, 25)]
    melted = source.melt(id_vars=['month'], value_vars=value_cols, var_name='hour_col', value_name='val')
    
    # Map hour_col to integer hour
    melted['hour'] = melted['hour_col'].str.extract('(\d+)').astype(int)
    
    # Group by hour and month, calculate mean
    grouped = melted.groupby(['hour', 'month'])['val'].mean().reset_index()
    
    # Pivot to get months as columns
    pivoted = grouped.pivot(index='hour', columns='month', values='val')
    
    # Define month names
    month_names = {
        1: 'january', 2: 'february', 3: 'march', 4: 'april', 5: 'may', 6: 'june',
        7: 'july', 8: 'august', 9: 'september', 10: 'october', 11: 'november', 12: 'december'
    }
    
    # Rename columns
    pivoted.columns = [month_names.get(col, col) for col in pivoted.columns]
    
    # Ensure all month columns exist, even if empty/null
    for m in month_names.values():
        if m not in pivoted.columns:
            pivoted[m] = np.nan
            
    # Select and order columns
    ordered_months = [month_names[i] for i in range(1, 13)]
    pivoted = pivoted[ordered_months]
    
    # Reset index to make 'hour' a column
    pivoted = pivoted.reset_index()
    
    # Ensure hour is int64
    pivoted['hour'] = pivoted['hour'].astype('int64')
    
    # Reorder columns to match target: hour, then months
    final_cols = ['hour'] + ordered_months
    result = pivoted[final_cols]
    
    return result
