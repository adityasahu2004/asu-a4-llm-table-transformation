import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse time
    source['dt'] = pd.to_datetime(source['time'])
    source['month'] = source['dt'].dt.month
    source['hour'] = source['dt'].dt.hour
    
    # Define column mappings for aggregation
    hvac_cols = [
        'electricity_heating_kwh',
        'electricity_central_system_heating_kwh',
        'electricity_cooling_kwh',
        'electricity_central_system_cooling_kwh',
        'electricity_fans_heating_kwh',
        'electricity_fans_cooling_kwh',
        'electricity_pumps_heating_kwh',
        'electricity_central_system_pumps_heating_kwh',
        'electricity_pumps_cooling_kwh',
        'electricity_central_system_pumps_cooling_kwh'
    ]
    
    water_cols = [
        'electricity_water_systems_kwh'
    ]
    
    major_appliance_cols = [
        'electricity_refrigerator_kwh',
        'electricity_clothes_washer_kwh',
        'electricity_clothes_dryer_kwh',
        'electricity_cooking_range_kwh',
        'electricity_dishwasher_kwh'
    ]
    
    lighting_cols = [
        'electricity_interior_lighting_kwh',
        'electricity_exterior_lighting_kwh'
    ]
    
    misc_plug_cols = [
        'electricity_plug_loads_kwh',
        'electricity_house_fan_kwh',
        'electricity_range_fan_kwh',
        'electricity_bath_fan_kwh',
        'electricity_ceiling_fan_kwh',
        'electricity_pool_heater_kwh',
        'electricity_pool_pump_kwh',
        'electricity_hot_tub_heater_kwh',
        'electricity_hot_tub_pump_kwh'
    ]
    
    # Create temporary columns for categories
    source['hvac'] = source[hvac_cols].sum(axis=1)
    source['domestic_water_heating'] = source[water_cols].sum(axis=1)
    source['major_appliances'] = source[major_appliance_cols].sum(axis=1)
    source['lighting'] = source[lighting_cols].sum(axis=1)
    source['miscellaneous_plug_loads'] = source[misc_plug_cols].sum(axis=1)
    
    # Calculate total as sum of categories
    source['total'] = (source['hvac'] + source['domestic_water_heating'] + 
                       source['major_appliances'] + source['lighting'] + 
                       source['miscellaneous_plug_loads'])
    
    # Group by month and hour, summing the categories
    agg_cols = ['hvac', 'domestic_water_heating', 'major_appliances', 'lighting', 'miscellaneous_plug_loads', 'total']
    
    result = source.groupby(['month', 'hour'])[agg_cols].sum().reset_index()
    
    # Ensure correct column order and types
    result = result[['month', 'hour', 'hvac', 'domestic_water_heating', 'major_appliances', 'lighting', 'miscellaneous_plug_loads', 'total']]
    
    return result
