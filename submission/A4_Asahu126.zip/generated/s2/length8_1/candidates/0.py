import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    # Parse dates
    df = source.copy()
    df['dt'] = pd.to_datetime(df['date'], format='%m/%d/%Y %H:%M')
    df['hour'] = df['dt'].dt.hour
    df['month'] = df['dt'].dt.month

    # Group by hour and month, compute mean
    grouped = df.groupby(['hour', 'month'])['cerc_logger_1'].mean().reset_index()

    # Pivot to wide format
    pivoted = grouped.pivot(index='hour', columns='month', values='cerc_logger_1')

    # Rename columns to month names
    month_names = {
        1: 'January', 2: 'February', 3: 'March', 4: 'April',
        5: 'May', 6: 'June', 7: 'July', 8: 'August',
        9: 'September', 10: 'October', 11: 'November', 12: 'December'
    }
    pivoted.rename(columns=month_names, inplace=True)

    # Ensure all month columns exist (in case some months are missing in data)
    for m in range(1, 13):
        if month_names[m] not in pivoted.columns:
            pivoted[month_names[m]] = np.nan

    # Select and order columns
    month_cols = [month_names[m] for m in range(1, 13)]
    pivoted = pivoted[month_cols]

    # Reset index and rename hour column
    pivoted = pivoted.reset_index()
    pivoted.rename(columns={'hour': 'Hour'}, inplace=True)

    # Sort by Hour
    pivoted = pivoted.sort_values('Hour').reset_index(drop=True)

    return pivoted
