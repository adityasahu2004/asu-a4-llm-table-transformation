import pandas as pd
import numpy as np

def transform(source: pd.DataFrame) -> pd.DataFrame:
    """
    Transforms the source DataFrame by:
    1. Parsing the 'Date' column to extract month name and day type (weekday/weekend).
    2. Renaming the hourly columns from 'H:00' format to 'hrH' format.
    3. Returning a DataFrame with columns: month, daytype, hr1...hr24.
    """
    
    # 1. Parse Date
    # Format: "Thu 10/01/2009" -> "%a %m/%d/%Y"
    # We need to handle the day name abbreviation correctly. 
    # pandas to_datetime handles this, but let's be explicit if needed.
    # The sample shows "Thu", "Fri", etc.
    source['parsed_date'] = pd.to_datetime(source['Date'], format='%a %m/%d/%Y')
    
    # 2. Derive 'month'
    # Extract full month name
    source['month'] = source['parsed_date'].dt.strftime('%B')
    
    # 3. Derive 'daytype'
    # weekday() returns 0 for Monday, 6 for Sunday.
    # Weekend is 5 (Saturday) or 6 (Sunday).
    source['daytype'] = np.where(
        source['parsed_date'].dt.weekday >= 5, 
        'weekend', 
        'weekday'
    )
    
    # 4. Rename Hour Columns
    # Source columns: "1:00", "2:00", ..., "23:00", "24:00:00"
    # Target columns: "hr1", "hr2", ..., "hr23", "hr24"
    
    rename_map = {}
    for i in range(1, 24):
        rename_map[f"{i}:00"] = f"hr{i}"
    rename_map["24:00:00"] = "hr24"
    
    # Apply rename
    df_renamed = source.rename(columns=rename_map)
    
    # 5. Select and Order Columns
    # Target order: month, daytype, hr1, hr2, ..., hr24
    hour_cols = [f"hr{i}" for i in range(1, 25)]
    final_cols = ['month', 'daytype'] + hour_cols
    
    result = df_renamed[final_cols].copy()
    
    # Clean up temporary column if necessary, though we selected specific cols
    # Ensure dtypes are correct (month and daytype are str, hrs are float)
    # The source hrs are already float64.
    
    return result
